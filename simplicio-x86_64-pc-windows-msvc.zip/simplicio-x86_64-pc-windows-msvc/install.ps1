#!/usr/bin/env pwsh
# Simplicio installer for Windows — binary + always-on Claude integration.
#   powershell -c "irm https://simpleti.com.br/simplicio/install.ps1 | iex"
#
# Flags (set before piping, e.g. $env:SIMPLICIO_NO_CLAUDE=1):
#   SIMPLICIO_NO_CLAUDE=1   binary only (skip the always-on skill + hook)
#   SIMPLICIO_LANG=pt|en    force message language (default: auto from culture)
# By default it installs everything (binary + Claude skill + SessionStart hook).

$ErrorActionPreference = "Stop"
$Base      = "https://simpleti.com.br/simplicio"
$BinDir    = Join-Path $env:USERPROFILE ".local\bin"
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
$RuntimeHome = if ($env:SIMPLICIO_HOME) { $env:SIMPLICIO_HOME } else { Join-Path $env:USERPROFILE ".simplicio" }
$MemoryDb = if ($env:SIMPLICIO_MEMORY_DB) { $env:SIMPLICIO_MEMORY_DB } else { Join-Path $RuntimeHome "memory\simplicio-memory.sqlite" }
$AgentHome = if ($env:SIMPLICIO_AGENT_HOME) { $env:SIMPLICIO_AGENT_HOME } else { Join-Path $env:USERPROFILE ".simplicio_agent" }
$CodeHome = if ($env:SIMPLICIO_CODE_HOME) { $env:SIMPLICIO_CODE_HOME } else { Join-Path $RuntimeHome "code" }
$WithClaude = -not $env:SIMPLICIO_NO_CLAUDE

# ---- language (pt | en) ----
$L = $env:SIMPLICIO_LANG
if (-not $L) {
  $L = if ((Get-Culture).Name -like "pt*") { "pt" } else { "en" }
}

function Say($m) { Write-Host "› $m" -ForegroundColor Cyan }
function Msg($pt, $en) { if ($L -eq "pt") { Say $pt } else { Say $en } }

function Install-SimplicioAgent {
  $python = @("python3.13", "python3.12", "python3.11", "py") |
    Where-Object { Get-Command $_ -ErrorAction SilentlyContinue } |
    Select-Object -First 1
  if (-not $python) { throw "Python 3.11-3.13 is required for Simplicio Agent" }
  New-Item -ItemType Directory -Force -Path $AgentHome | Out-Null
  $agentPython = Join-Path $AgentHome "venv\Scripts\python.exe"
  if (-not (Test-Path $agentPython)) {
    if ($python -eq "py") {
      $created = $false
      foreach ($version in @("-3.13", "-3.12", "-3.11")) {
        & py $version -m venv (Join-Path $AgentHome "venv") 2>$null
        if ($LASTEXITCODE -eq 0) { $created = $true; break }
      }
      if (-not $created) { throw "Python launcher has no Python 3.11-3.13 runtime" }
    }
    else { & $python -m venv (Join-Path $AgentHome "venv") }
  }
  & $agentPython -m pip install --quiet --upgrade pip wheel
  & $agentPython -m pip install --quiet --upgrade `
    "simplicio-agent[fast,ecosystem] @ https://github.com/wesleysimplicio/simplicio-agent/archive/refs/heads/main.tar.gz"
  if ($LASTEXITCODE -ne 0) { throw "Simplicio Agent installation failed" }
  $agentCmd = Join-Path $BinDir "simplicio-agent.cmd"
  @"
@echo off
set "SIMPLICIO_HOME=$RuntimeHome"
set "SIMPLICIO_AGENT_HOME=$AgentHome"
set "HERMES_HOME=$AgentHome"
"$agentPython" -m simplicio_agent_cli.main %*
"@ | Set-Content -Path $agentCmd -Encoding ASCII
  & $agentCmd --help | Out-Null
}

function Start-SimplicioAgent {
  $agentCmd = Join-Path $BinDir "simplicio-agent.cmd"
  $agentSocket = Join-Path $AgentHome "daemon.sock"
  & $agentCmd daemon status --socket $agentSocket 2>$null | Out-Null
  if ($LASTEXITCODE -eq 0) { return }

  $agentPython = Join-Path $AgentHome "venv\Scripts\python.exe"
  $env:SIMPLICIO_HOME = $RuntimeHome
  $env:SIMPLICIO_AGENT_HOME = $AgentHome
  $env:HERMES_HOME = $AgentHome
  Start-Process -FilePath $agentPython -WindowStyle Hidden `
    -ArgumentList @("-m", "simplicio_agent_cli.main", "daemon", "start", "--socket", $agentSocket)
  foreach ($attempt in 1..30) {
    Start-Sleep -Milliseconds 200
    & $agentCmd daemon status --socket $agentSocket 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { return }
  }
  throw "Simplicio Agent daemon did not become healthy"
}

function Install-SimplicioCode {
  $codeBin = Join-Path $CodeHome "bin"
  New-Item -ItemType Directory -Force -Path $codeBin | Out-Null
  $codeInstaller = Join-Path $TempRoot "simplicio-code-install.ps1"
  Invoke-WebRequest `
    -Uri "https://raw.githubusercontent.com/wesleysimplicio/simplicio-code/main/install.ps1" `
    -OutFile $codeInstaller -UseBasicParsing
  $powerShellHost = if (Get-Command pwsh -ErrorAction SilentlyContinue) {
    (Get-Command pwsh).Source
  } else {
    (Get-Command powershell).Source
  }
  & $powerShellHost -NoProfile -ExecutionPolicy Bypass -File $codeInstaller -BinDir $codeBin
  if ($LASTEXITCODE -ne 0) {
    if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
      throw "Simplicio Code binary release is unavailable and the fallback requires Cargo"
    }
    Msg "Release binario indisponivel; compilando o Simplicio Code pelo repositorio oficial..." `
        "Binary release unavailable; building Simplicio Code from the official repository..."
    & cargo install --git https://github.com/wesleysimplicio/simplicio-code.git `
      --locked --package xai-grok-pager-bin --bin simplicio-code --root $CodeHome
    if ($LASTEXITCODE -ne 0) { throw "Simplicio Code source installation failed" }
  }
  $codeExe = Join-Path $codeBin "simplicio-code.exe"
  if (-not (Test-Path $codeExe)) { throw "Simplicio Code binary is missing" }
  $codeCmd = Join-Path $BinDir "simplicio-code.cmd"
  @"
@echo off
set "SIMPLICIO_HOME=$RuntimeHome"
set "SIMPLICIO_AGENT_HOME=$AgentHome"
set "SIMPLICIO_AGENT_SOCKET=$AgentHome\daemon.sock"
"$codeExe" %*
"@ | Set-Content -Path $codeCmd -Encoding ASCII
  & $codeCmd --version | Out-Null
}

# ---- 1. binary ----
$Arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
Msg "Instalando o binário simplicio (windows/$Arch)…" `
    "Installing the simplicio binary (windows/$Arch)…"
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
$BinPath = Join-Path $BinDir "simplicio.exe"
$TempRoot = Join-Path ([IO.Path]::GetTempPath()) ("simplicio-install-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
$StageBin = Join-Path $TempRoot "simplicio.exe"

# Primary (simpleti.com.br CDN) then PUBLIC GitHub Releases fallback. Prefer the
# portable ZIP so Windows users can reuse the same asset for manual installs and
# future winget/scoop flows. The `-runtime` repo is private (closed).
$GitHubBase = "https://github.com/wesleysimplicio/simplicio/releases/latest/download"
$zipUrls = @(
  "$Base/dist/simplicio-windows-$Arch.zip",
  "$GitHubBase/simplicio-windows-$Arch.zip"
)
$exeUrls = @(
  "$Base/dist/simplicio-windows-$Arch.exe",
  "$GitHubBase/simplicio-windows-$Arch.exe",
  "$GitHubBase/simplicio-windows-$Arch"
)
$dlOk = $false
$zipPath = Join-Path $TempRoot "simplicio.zip"
foreach ($u in $zipUrls) {
  try {
    Invoke-WebRequest -Uri $u -OutFile $zipPath -UseBasicParsing -TimeoutSec 30
    if ((Test-Path $zipPath) -and ((Get-Item $zipPath).Length -gt 0)) {
      $extractDir = Join-Path $TempRoot "portable"
      Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
      $portableBin = Get-ChildItem -Path $extractDir -Recurse -Filter "simplicio.exe" | Select-Object -First 1
      if ($portableBin) {
        Copy-Item $portableBin.FullName $StageBin -Force
        $dlOk = $true
        break
      }
    }
  } catch { }
}
if (-not $dlOk) {
  foreach ($u in $exeUrls) {
    try {
      Invoke-WebRequest -Uri $u -OutFile $StageBin -UseBasicParsing -TimeoutSec 30
      if ((Test-Path $StageBin) -and ((Get-Item $StageBin).Length -gt 0)) { $dlOk = $true; break }
    } catch { }
  }
}
if ($dlOk) {
  if (Test-Path $BinPath) { Remove-Item $BinPath -Force }
  Move-Item $StageBin $BinPath -Force
  Msg "Binário em $BinPath" "Binary at $BinPath"
} else {
  Msg "Não consegui baixar o binário para windows/$Arch. Baixe manualmente:" `
      "Could not download the binary for windows/$Arch. Download it manually:"
  Say "  https://simpleti.com.br/simplicio/dist/simplicio-windows-$Arch.zip"
  exit 1
}

# PATH (user scope) — add ~/.local/bin if missing
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$BinDir*") {
  [Environment]::SetEnvironmentVariable("Path", "$userPath;$BinDir", "User")
  Msg "Adicionado ao PATH (reabra o terminal): $BinDir" `
      "Added to PATH (reopen your terminal): $BinDir"
}

if (Get-Command simplicio -ErrorAction SilentlyContinue) {
  Msg "Reparando a instalacao para exatidao (doctor --repair)..." "Repairing the install for accuracy (doctor --repair)..."
  & $BinPath doctor --repair 2>$null | Out-Null
}

if ($env:SIMPLICIO_SKIP_ECOSYSTEM -ne "1") {
  Msg "Instalando o Simplicio Agent (control plane)..." "Installing Simplicio Agent (control plane)..."
  Install-SimplicioAgent
  Start-SimplicioAgent
  Msg "Instalando o Simplicio Code ligado ao Agent..." "Installing Simplicio Code wired to Agent..."
  Install-SimplicioCode
}

# Neural memory bootstrap and honest install verification. Set SIMPLICIO_SKIP_VERIFY=1 to skip.
if ($env:SIMPLICIO_SKIP_VERIFY -eq "1") {
  Msg "Verificacao pos-instalacao ignorada (SIMPLICIO_SKIP_VERIFY=1)." "Post-install verification skipped (SIMPLICIO_SKIP_VERIFY=1)."
} else {
  try {
    New-Item -ItemType Directory -Force -Path (Split-Path $MemoryDb -Parent) | Out-Null
    $env:SIMPLICIO_HOME = $RuntimeHome
    $env:SIMPLICIO_MEMORY_DB = $MemoryDb
    & $BinPath memory init --scope runtime --json
    if ($LASTEXITCODE -ne 0) { throw "memory init exited with code $LASTEXITCODE" }
    & $BinPath memory-db "post-install smoke" --repo . --json
    if ($LASTEXITCODE -ne 0) { throw "memory-db smoke exited with code $LASTEXITCODE" }
    Msg "Banco neural inicializado com seeds em $MemoryDb." "Neural database initialized with seeds at $MemoryDb."
  } catch {
    throw "post-install neural verification failed: $($_.Exception.Message)"
  }
}

# ---- 2. always-on Claude integration (skill + SessionStart hook) ----
if ($WithClaude) {
  Msg "Instalando a integração Claude (skill + hook sempre-ativo)…" `
      "Installing the Claude integration (always-on skill + hook)…"
  $skillDir = Join-Path $ClaudeDir "skills\simplicio"
  New-Item -ItemType Directory -Force -Path $skillDir | Out-Null
  try {
    Invoke-WebRequest -Uri "$Base/claude/SKILL.md" -OutFile (Join-Path $skillDir "SKILL.md") -UseBasicParsing
    Invoke-WebRequest -Uri "$Base/claude/settings.json" -OutFile (Join-Path $ClaudeDir "simplicio-hook.json") -UseBasicParsing
    Msg "Skill + hook instalados em $ClaudeDir" "Skill + hook installed at $ClaudeDir"
  } catch {
    Msg "Integração Claude opcional não publicada ainda; binário instalado. Pule com SIMPLICIO_NO_CLAUDE=1." `
        "Optional Claude integration not published yet; binary installed. Skip with SIMPLICIO_NO_CLAUDE=1."
  }

  # statusline badge — shows [SIMPLICIO] in Claude Code when the repo is simplicio-enabled
  try {
    $hooksDir = Join-Path $ClaudeDir "hooks"
    New-Item -ItemType Directory -Force -Path $hooksDir | Out-Null
    $slPath = Join-Path $hooksDir "simplicio-statusline.ps1"
    Invoke-WebRequest -Uri "$Base/hooks/statusline.ps1" -OutFile $slPath -UseBasicParsing
    $settingsPath = Join-Path $ClaudeDir "settings.json"
    $settings = if (Test-Path $settingsPath) { Get-Content $settingsPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
    $slCmd = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$slPath`""
    $cur = if ($settings.PSObject.Properties["statusLine"]) { $settings.statusLine.command } else { "" }
    if (-not $cur) {
      $settings | Add-Member -Force -NotePropertyName statusLine -NotePropertyValue ([pscustomobject]@{ type = "command"; command = $slCmd })
      $settings | ConvertTo-Json -Depth 16 | Set-Content $settingsPath -Encoding UTF8
      Msg "Statusline [SIMPLICIO] ativada no Claude Code." `
          "[SIMPLICIO] statusline enabled in Claude Code."
    }
  } catch {
    Msg "Statusline opcional não instalada (sem problema)." `
        "Optional statusline not installed (no problem)."
  }
}

# ---- editor badge (VS Code, Cursor, Windsurf, Antigravity) ----
try {
  $vsix = Join-Path $env:USERPROFILE ".simplicio\simplicio-badge.vsix"
  New-Item -ItemType Directory -Force -Path (Split-Path $vsix) | Out-Null
  Invoke-WebRequest -Uri "$Base/dist/simplicio-badge.vsix" -OutFile $vsix -UseBasicParsing
  foreach ($ed in @("code", "cursor", "windsurf", "antigravity", "codium")) {
    if (Get-Command $ed -ErrorAction SilentlyContinue) {
      & $ed --install-extension $vsix 2>$null | Out-Null
      Msg "Badge [SIMPLICIO] instalado no $ed." "[SIMPLICIO] badge installed in $ed."
    }
  }
} catch {}

Msg "Pronto. Rode: simplicio --help" "Done. Run: simplicio --help"
Msg "Beta gratuita até 2026-06-30 — todas as features liberadas." `
    "Free beta until 2026-06-30 — all features unlocked."
