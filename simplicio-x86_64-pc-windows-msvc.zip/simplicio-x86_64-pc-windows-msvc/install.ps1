#!/usr/bin/env pwsh
# Simplicio installer for Windows — binary + always-on Claude integration.
#   powershell -c "irm https://simpleti.com.br/simplicio/install.ps1 | iex"
#
# Flags (set before piping, e.g. $env:SIMPLICIO_NO_CLAUDE=1):
#   SIMPLICIO_NO_CLAUDE=1   binary only (skip the always-on skill + hook)
#   SIMPLICIO_LANG=pt|en    force message language (default: auto from culture)
# By default it installs everything (binary + Claude skill + SessionStart hook).

$ErrorActionPreference = "Stop"
$Base      = "https://simpleti.com.br/simplicio"
$BinDir    = Join-Path $env:USERPROFILE ".local\bin"
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
$WithClaude = -not $env:SIMPLICIO_NO_CLAUDE

# ---- language (pt | en) ----
$L = $env:SIMPLICIO_LANG
if (-not $L) {
  $L = if ((Get-Culture).Name -like "pt*") { "pt" } else { "en" }
}

function Say($m) { Write-Host "› $m" -ForegroundColor Cyan }
function Msg($pt, $en) { if ($L -eq "pt") { Say $pt } else { Say $en } }

# ---- 1. binary ----
$Arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
Msg "Instalando o binário simplicio (windows/$Arch)…" `
    "Installing the simplicio binary (windows/$Arch)…"
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
$BinPath = Join-Path $BinDir "simplicio.exe"
$TempRoot = Join-Path ([IO.Path]::GetTempPath()) ("simplicio-install-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
$StageBin = Join-Path $TempRoot "simplicio.exe"

# Primary (simpleti.com.br CDN) then PUBLIC GitHub Releases fallback. Prefer the
# portable ZIP so Windows users can reuse the same asset for manual installs and
# future winget/scoop flows. The `-runtime` repo is private (closed).
$GitHubBase = "https://github.com/wesleysimplicio/simplicio/releases/latest/download"
$zipUrls = @(
  "$Base/dist/simplicio-windows-$Arch.zip",
  "$GitHubBase/simplicio-windows-$Arch.zip"
)
$exeUrls = @(
  "$Base/dist/simplicio-windows-$Arch.exe",
  "$GitHubBase/simplicio-windows-$Arch.exe",
  "$GitHubBase/simplicio-windows-$Arch"
)
$dlOk = $false
$zipPath = Join-Path $TempRoot "simplicio.zip"
foreach ($u in $zipUrls) {
  try {
    Invoke-WebRequest -Uri $u -OutFile $zipPath -UseBasicParsing -TimeoutSec 30
    if ((Test-Path $zipPath) -and ((Get-Item $zipPath).Length -gt 0)) {
      $extractDir = Join-Path $TempRoot "portable"
      Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
      $portableBin = Get-ChildItem -Path $extractDir -Recurse -Filter "simplicio.exe" | Select-Object -First 1
      if ($portableBin) {
        Copy-Item $portableBin.FullName $StageBin -Force
        $dlOk = $true
        break
      }
    }
  } catch { }
}
if (-not $dlOk) {
  foreach ($u in $exeUrls) {
    try {
      Invoke-WebRequest -Uri $u -OutFile $StageBin -UseBasicParsing -TimeoutSec 30
      if ((Test-Path $StageBin) -and ((Get-Item $StageBin).Length -gt 0)) { $dlOk = $true; break }
    } catch { }
  }
}
if ($dlOk) {
  if (Test-Path $BinPath) { Remove-Item $BinPath -Force }
  Move-Item $StageBin $BinPath -Force
  Msg "Binário em $BinPath" "Binary at $BinPath"
} else {
  Msg "Não consegui baixar o binário para windows/$Arch. Baixe manualmente:" `
      "Could not download the binary for windows/$Arch. Download it manually:"
  Say "  https://simpleti.com.br/simplicio/dist/simplicio-windows-$Arch.zip"
  exit 1
}

# PATH (user scope) — add ~/.local/bin if missing
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$BinDir*") {
  [Environment]::SetEnvironmentVariable("Path", "$userPath;$BinDir", "User")
  Msg "Adicionado ao PATH (reabra o terminal): $BinDir" `
      "Added to PATH (reopen your terminal): $BinDir"
}

# ---- 1.5. local model (GGUF) + doctor repair — exact, offline-ready install ----
if (Get-Command simplicio -ErrorAction SilentlyContinue) {
  Msg "Reparando a instalacao para exatidao (doctor --repair)..." "Repairing the install for accuracy (doctor --repair)..."
  & simplicio doctor --repair 2>$null | Out-Null
  if ($env:SIMPLICIO_NO_MODEL -ne "1") {
    Msg "Baixando o modelo local (GGUF ~1.3 GB) para modo offline/local-first..." "Downloading the local model (GGUF ~1.3 GB) for offline/local-first mode..."
    & simplicio model smoke --run 2>$null | Out-Null
    if ((& simplicio model 2>$null) -match '"offline_ready":true') {
      Msg "Modelo local pronto (offline-ready)." "Local model ready (offline-ready)."
    } else {
      Msg "Modelo nao baixou agora; rode depois: simplicio model smoke --run" "Model didn't download now; run later: simplicio model smoke --run"
    }
  }
}

# ---- 2. always-on Claude integration (skill + SessionStart hook) ----
if ($WithClaude) {
  Msg "Instalando a integração Claude (skill + hook sempre-ativo)…" `
      "Installing the Claude integration (always-on skill + hook)…"
  $skillDir = Join-Path $ClaudeDir "skills\simplicio"
  New-Item -ItemType Directory -Force -Path $skillDir | Out-Null
  try {
    Invoke-WebRequest -Uri "$Base/claude/SKILL.md" -OutFile (Join-Path $skillDir "SKILL.md") -UseBasicParsing
    Invoke-WebRequest -Uri "$Base/claude/settings.json" -OutFile (Join-Path $ClaudeDir "simplicio-hook.json") -UseBasicParsing
    Msg "Skill + hook instalados em $ClaudeDir" "Skill + hook installed at $ClaudeDir"
  } catch {
    Msg "Integração Claude opcional não publicada ainda; binário instalado. Pule com SIMPLICIO_NO_CLAUDE=1." `
        "Optional Claude integration not published yet; binary installed. Skip with SIMPLICIO_NO_CLAUDE=1."
  }

  # statusline badge — shows [SIMPLICIO] in Claude Code when the repo is simplicio-enabled
  try {
    $hooksDir = Join-Path $ClaudeDir "hooks"
    New-Item -ItemType Directory -Force -Path $hooksDir | Out-Null
    $slPath = Join-Path $hooksDir "simplicio-statusline.ps1"
    Invoke-WebRequest -Uri "$Base/hooks/statusline.ps1" -OutFile $slPath -UseBasicParsing
    $settingsPath = Join-Path $ClaudeDir "settings.json"
    $settings = if (Test-Path $settingsPath) { Get-Content $settingsPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
    $slCmd = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$slPath`""
    $cur = if ($settings.PSObject.Properties["statusLine"]) { $settings.statusLine.command } else { "" }
    if (-not $cur) {
      $settings | Add-Member -Force -NotePropertyName statusLine -NotePropertyValue ([pscustomobject]@{ type = "command"; command = $slCmd })
      $settings | ConvertTo-Json -Depth 16 | Set-Content $settingsPath -Encoding UTF8
      Msg "Statusline [SIMPLICIO] ativada no Claude Code." `
          "[SIMPLICIO] statusline enabled in Claude Code."
    }
  } catch {
    Msg "Statusline opcional não instalada (sem problema)." `
        "Optional statusline not installed (no problem)."
  }
}

# ---- editor badge (VS Code, Cursor, Windsurf, Antigravity) ----
try {
  $vsix = Join-Path $env:USERPROFILE ".simplicio\simplicio-badge.vsix"
  New-Item -ItemType Directory -Force -Path (Split-Path $vsix) | Out-Null
  Invoke-WebRequest -Uri "$Base/dist/simplicio-badge.vsix" -OutFile $vsix -UseBasicParsing
  foreach ($ed in @("code", "cursor", "windsurf", "antigravity", "codium")) {
    if (Get-Command $ed -ErrorAction SilentlyContinue) {
      & $ed --install-extension $vsix 2>$null | Out-Null
      Msg "Badge [SIMPLICIO] instalado no $ed." "[SIMPLICIO] badge installed in $ed."
    }
  }
} catch {}

Msg "Pronto. Rode: simplicio --help" "Done. Run: simplicio --help"
Msg "Beta gratuita até 2026-06-30 — todas as features liberadas." `
    "Free beta until 2026-06-30 — all features unlocked."
