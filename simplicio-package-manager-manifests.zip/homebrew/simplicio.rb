class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.6.4"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.4/simplicio-darwin-arm64"
      sha256 "dcf699e4bd2ae1edbc75c64a247e8e31f32086635d5dd1626cf29077e7f52f51"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.4/simplicio-darwin-x64"
      sha256 "7f1035be4cc2cf6a5053d894159622b233ca0fad00a5215f9ece3772fe462c42"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end