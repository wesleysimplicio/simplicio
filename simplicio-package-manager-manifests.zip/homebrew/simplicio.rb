class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.6.2"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.2/simplicio-darwin-arm64"
      sha256 "7f6d669bc7205a9a656036cdb5c22fbe0c5c952afefb8cb36b92aaad1d3dfa21"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.2/simplicio-darwin-x64"
      sha256 "d1bd14a4083b397ac642606ea2957b4bf36e15be25de82363e29c2b751131a12"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end