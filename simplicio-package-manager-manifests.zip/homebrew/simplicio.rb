class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.6.0"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.0/simplicio-darwin-arm64"
      sha256 "1ad4b6727dd8173d2a42522440fde21f35579d37fd5f2730086d67e9b80352b1"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.0/simplicio-darwin-x64"
      sha256 "ca28fe0c8e472771caba34a78bcaaa3b2aeea1e85fa044db8cd6bdfad0483a63"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end