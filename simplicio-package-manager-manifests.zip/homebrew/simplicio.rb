class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.6.4"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.4/simplicio-darwin-arm64"
      sha256 "50affbf647d9bb032049d7be86ce8f700b28ccec6df016d0c58cdcfd2d84db4c"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.4/simplicio-darwin-x64"
      sha256 "931975ba69ceae2e5ad71c895bc163e0ba996e5ed820b56cd8aa8a746b6d6e81"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end