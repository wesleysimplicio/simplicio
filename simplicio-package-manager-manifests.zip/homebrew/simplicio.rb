class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.4.9"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.4.9/simplicio-darwin-arm64"
      sha256 "f699b9efac2e8c6c13b0b4f71325cf88840a343ed7e698069f356b3e42ab14cd"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.4.9/simplicio-darwin-x64"
      sha256 "42107f99284f1e5671e6a7ba50a9e21058b7d49ddbb0efea0d1beb3b22471999"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end