class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.5.0"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.5.0/simplicio-darwin-arm64"
      sha256 "d3e4ea1ebec12ed999b38a1c07bb0f4d07e343e9129bc726a93360e32dd312eb"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.5.0/simplicio-darwin-x64"
      sha256 "151d2d47b053d72ea68268e37506c95667e47f1d4ec058a7d6b1175aba9301b9"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end