class Simplicio < Formula
  desc "Native orchestration runtime for the Simplicio ecosystem"
  homepage "https://github.com/wesleysimplicio/simplicio"
  version "1.6.1"
  license "MIT"

  on_macos do
    if Hardware::CPU.arm?
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.1/simplicio-darwin-arm64"
      sha256 "0cdcaf26d855eda8c9dca3031b0a88b5a50a32bae3a7db0741533e916f7b2d39"
    else
      url "https://github.com/wesleysimplicio/simplicio/releases/download/v1.6.1/simplicio-darwin-x64"
      sha256 "b5e369f9903290eb2c7a0e7b756b494e3d0dd1a83e942e789197839ea54e44fc"
    end
  end

  def install
    binary = Dir["simplicio-darwin-*"].first
    bin.install binary => "simplicio"
  end

  test do
    system "#{bin}/simplicio", "version"
  end
end